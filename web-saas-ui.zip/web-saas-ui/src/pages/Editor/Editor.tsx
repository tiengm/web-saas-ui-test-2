import React from 'react';
import './Editor.scss';

import { TopBar } from './TopBar';
import { EditorLeftPanel } from './EditorLeftPanel';
import { EditorPreview } from './EditorPreview';

export const Editor = () => {
    return (
        <div className="ws-wrapper">
            <TopBar />
            <div className="ws-main ws-editor-main">
                <EditorLeftPanel />
                <EditorPreview />
            </div>
        </div>
    );
};
