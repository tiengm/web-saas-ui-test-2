import React, { useState } from 'react';
import classnames from 'classnames';
import Tippy from '@tippyjs/react';
import './TopBar.scss';

// svgs
import { ReactComponent as LogoIcon } from '~/assets/svgs/logo.svg';
import { ReactComponent as SearchOutlineIcon } from '~/assets/svgs/search-outline.svg';
import { ReactComponent as DesktopOutlineIcon } from '~/assets/svgs/desktop-outline.svg';
import { ReactComponent as PhonePortraitOutlineIcon } from '~/assets/svgs/phone-portrait-outline.svg';
import { ReactComponent as UndoIcon } from '~/assets/svgs/undo.svg';
import { ReactComponent as RedoIcon } from '~/assets/svgs/redo.svg';
import { ReactComponent as ArrowUpOutlineIcon } from '~/assets/svgs/arrow-up-outline.svg';
import { ReactComponent as NotificationsIcon } from '~/assets/svgs/notifications.svg';

import { Notifications } from './Notifications';

export const TopBar = () => {
    const [searchText, setSearchText] = useState('');
    const [isFocus, setIsFocus] = useState(false);

    const handleFocus = () => setIsFocus(true);
    const handleBlur = () => setIsFocus(false);

    return (
        <div className="ws-top-bar">
            <div className="ws-top-bar-start">
                <div className="ws-top-bar-logo">
                    <LogoIcon />
                </div>
                <form className="ws-top-bar-search">
                    <div
                        className={classnames('ws-top-bar-search__icon', {
                            'ws-top-bar-search__icon--hide': isFocus || searchText.length > 0,
                            'ws-top-bar-search__icon--show': !isFocus && searchText.length === 0,
                        })}
                    >
                        <SearchOutlineIcon />
                    </div>
                    <div className="ws-top-bar-search__input-container">
                        <input
                            type="text"
                            className="ws-top-bar-search__input"
                            onFocus={handleFocus}
                            onBlur={handleBlur}
                            value={searchText}
                            onChange={(e) => setSearchText(e.target.value)}
                        />
                    </div>
                </form>
            </div>
            <div className="ws-top-bar-content">
                <div className="ws-top-bar-content__item ws-top-bar-content__left">
                    <Tippy
                        className="ws-top-bar-content-tippy"
                        content={
                            <>
                                <div className="ws-top-bar-content-tippy__title font-18r">Switch to Desktop</div>
                                <div className="font-14l">Edit your site for desktop.</div>
                            </>
                        }
                        interactive={true}
                        duration={200}
                        placement="bottom"
                    >
                        <div className="ws-top-bar-content__tooltip">
                            <div className="ws-top-bar-content__tooltip-container">
                                <div className="ws-top-bar-content__tooltip__icon">
                                    <DesktopOutlineIcon />
                                </div>
                            </div>
                        </div>
                    </Tippy>
                    <Tippy
                        className="ws-top-bar-content-tippy"
                        content={
                            <>
                                <div className="ws-top-bar-content-tippy__title font-18r">Switch to Mobile</div>
                                <div className="font-14l">Edit your site for mobile.</div>
                            </>
                        }
                        interactive={true}
                        duration={200}
                        placement="bottom"
                    >
                        <div className="ws-top-bar-content__tooltip">
                            <div className="ws-top-bar-content__tooltip-container">
                                <div className="ws-top-bar-content__tooltip__icon">
                                    <PhonePortraitOutlineIcon />
                                </div>
                            </div>
                        </div>
                    </Tippy>
                </div>
                <div className="ws-top-bar-content__item ws-top-bar-content__center">
                    <Tippy
                        className="ws-top-bar-content-tippy"
                        content={
                            <>
                                <div className="ws-top-bar-content-tippy__title font-18r">Switch to Desktop</div>
                                <div className="font-14l">Edit your site for desktop.</div>
                            </>
                        }
                        interactive={true}
                        duration={200}
                        placement="bottom"
                    >
                        <div className="ws-top-bar-content__tooltip">
                            <div className="ws-top-bar-content__tooltip-container ws-top-bar-content__tooltip-container-undo-redo ws-top-bar-content__tooltip-container-undo">
                                <div className="ws-top-bar-content__tooltip__icon">
                                    <UndoIcon />
                                </div>
                                <div className="ws-top-bar-content__tooltip__text font-14r">Undo</div>
                            </div>
                        </div>
                    </Tippy>
                    <hr className="ws-top-bar-content__hr" />
                    <Tippy
                        className="ws-top-bar-content-tippy"
                        content={
                            <>
                                <div className="ws-top-bar-content-tippy__title font-18r">Switch to Desktop</div>
                                <div className="font-14l">Edit your site for desktop.</div>
                            </>
                        }
                        interactive={true}
                        duration={200}
                        placement="bottom"
                    >
                        <div className="ws-top-bar-content__tooltip">
                            <div className="ws-top-bar-content__tooltip-container ws-top-bar-content__tooltip-container-undo-redo ws-top-bar-content__tooltip-container-redo">
                                <div className="ws-top-bar-content__tooltip__icon">
                                    <RedoIcon />
                                </div>
                                <div className="ws-top-bar-content__tooltip__text font-14r">Redo</div>
                            </div>
                        </div>
                    </Tippy>
                </div>
                <div className="ws-top-bar-content__item ws-top-bar-content__right">
                    <Tippy
                        className="ws-top-bar-content-tippy"
                        content={
                            <>
                                <div className="ws-top-bar-content-tippy__title font-18r">Switch to Desktop</div>
                                <div className="font-14l">Edit your site for desktop.</div>
                            </>
                        }
                        interactive={true}
                        duration={200}
                        placement="bottom"
                    >
                        <div className="ws-top-bar-content__tooltip">
                            <div className="ws-top-bar-content__tooltip-button ws-top-bar-content__tooltip-button-publish font-14r">
                                <div className="ws-top-bar-content__tooltip-button__text">Publish Site</div>
                                <div className="ws-top-bar-content__tooltip-button__icon">
                                    <ArrowUpOutlineIcon />
                                </div>
                            </div>
                        </div>
                    </Tippy>
                    {/* <Tippy
                        className="ws-top-bar-content-tippy ws-top-bar-content-tippy-notifications"
                        arrow={false}
                        content={<Notifications />}
                        interactive={true}
                        duration={200}
                        trigger="click"
                        placement="bottom"
                    >
                        <div className="ws-top-bar-content__tooltip">
                            <div className="ws-top-bar-content__tooltip-icon">
                                <NotificationsIcon />
                                <div className="ws-top-bar-content__tooltip-icon__number">9+</div>
                            </div>
                        </div>
                    </Tippy> */}
                </div>
            </div>
        </div>
    );
};
