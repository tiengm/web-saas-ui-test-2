import React from 'react';
import Tippy from '@tippyjs/react';
import './EditorAccount.scss';

// images
import AvatarImage from '~/assets/images/avatar.jpg';

// svgs
import { ReactComponent as LogoutIcon } from '~/assets/svgs/log-out.svg';
import { ReactComponent as DiamondIcon } from '~/assets/svgs/diamond.svg';

// components
import { Avatar } from '~/components/Avatar';

export const EditorAccount = () => {
    return (
        <Tippy
            className="ws-editor-account-tippy"
            content={
                <>
                    <div className="ws-editor-account__item">
                        <div className="ws-editor-account-current-user">
                            <div className="ws-editor-account-current-user__avatar">
                                <Avatar src={AvatarImage} width={48} height={48} noHover />
                            </div>
                            <div className="ws-text-truncation font-16m">Tien Pham</div>
                        </div>
                    </div>
                    <hr className="ws-editor-account__hr" />
                    <div className="ws-editor-account__item">
                        <div className="ws-editor-account-logout">
                            <div className="ws-editor-account-logout__prefix-icon">
                                <DiamondIcon />
                            </div>
                            <div className="">Pro Plan</div>
                        </div>
                    </div>
                    <div className="ws-editor-account__item">
                        <div className="ws-editor-account-logout">
                            <div className="ws-editor-account-logout__prefix-icon">
                                <LogoutIcon />
                            </div>
                            <div className="ws-editor-account-logout__text">Log out</div>
                        </div>
                    </div>
                </>
            }
            arrow
            interactive={true}
            trigger="click"
            duration={200}
        >
            <div className="ws-editor-account">
                <Avatar src={AvatarImage} width={38} height={38} noHover />
            </div>
        </Tippy>
    );
};
