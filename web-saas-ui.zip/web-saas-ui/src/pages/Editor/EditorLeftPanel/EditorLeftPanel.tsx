import React, { useState } from 'react';
import classnames from 'classnames';
import Tippy from '@tippyjs/react';
import './EditorLeftPanel.scss';

// svgs
import { ReactComponent as HelpOutlineIcon } from '~/assets/svgs/help-outline.svg';
import { ReactComponent as CloseOutlineIcon } from '~/assets/svgs/close-outline.svg';

// hooks
import { useComponentVisible } from '~/hooks';

// types
import { LeftPanelDialogProps } from '~/types';

import { EditorNav } from './EditorNav';
import { EditorAccount } from './EditorAccount';
import { EditorNotifications } from './EditorNotifications';

export const EditorLeftPanel = () => {
    const [dialog, setDialog] = useState<LeftPanelDialogProps>();
    const [borderColor, setBorderColor] = useState('#fff');
    const { ref, isComponentVisible, setIsComponentVisible } = useComponentVisible(false);

    const onVisible = () => {
        setIsComponentVisible(!isComponentVisible);
    };

    return (
        <div className="ws-editor-left-panel" ref={ref}>
            <div className="ws-editor-left-panel-container">
                <EditorNav
                    onVisible={onVisible}
                    isVisible={isComponentVisible}
                    setDialog={setDialog}
                    setBorderColor={setBorderColor}
                />
                <div>
                    <EditorNotifications />
                    <EditorAccount />
                </div>
            </div>
            <div
                className={classnames('ws-editor-left-panel-dialog', {
                    'ws-editor-left-panel-dialog--expended': isComponentVisible,
                })}
            >
                <div className="ws-editor-left-panel-dialog-container">
                    <div className="ws-editor-left-panel-dialog-card">
                        <div className="ws-editor-left-panel-dialog__head" style={{ borderTopColor: borderColor }}>
                            <div className="ws-editor-left-panel-dialog__title ws-text-truncation font-16m">
                                {dialog?.name}
                            </div>
                            <div className="ws-editor-left-panel-dialog__button">
                                <HelpOutlineIcon />
                            </div>
                            <div className="ws-editor-left-panel-dialog__button" onClick={onVisible}>
                                <CloseOutlineIcon />
                            </div>
                        </div>
                        <div className="ws-editor-left-panel-dialog__body">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate atque ipsam placeat
                            beatae maiores eligendi porro neque, eum voluptatum quas
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
