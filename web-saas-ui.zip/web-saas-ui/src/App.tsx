import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// pages
import { Editor } from './pages/Editor';

// contexts
import { useGlobalContext } from '~/contexts/GlobalContext';

// styles
import './styles/app.scss';

const App = () => {
    const { i18n } = useTranslation();
    const { language } = useGlobalContext();

    useEffect(() => {
        i18n.changeLanguage(language);
    }, [i18n, language]);

    return (
        <Router>
            <Routes>
                <Route path="/editor" element={<Editor />} />
            </Routes>
        </Router>
    );
};

export default App;
