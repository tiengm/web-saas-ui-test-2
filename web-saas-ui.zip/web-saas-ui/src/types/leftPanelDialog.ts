export interface LeftPanelDialogProps {
    id: string;
    name: string;
    content: React.ReactNode;
}
