import React from 'react';
import './GlobalStyles.scss';

interface GlobalStylesProps {
    children: React.ReactNode;
}

export const GlobalStyles = ({ children }: GlobalStylesProps) => {
    return <>{children}</>;
};
