import React from 'react';
import './ErrorFallback.scss';

export const ErrorFallback = () => {
    return (
        <div role="alert" className="ws-error-fallback">
            <h2 className="font-18m">Ooops, something went wrong :( </h2>
            <button onClick={() => window.location.assign(window.location.origin)}>Refresh</button>
        </div>
    );
};
