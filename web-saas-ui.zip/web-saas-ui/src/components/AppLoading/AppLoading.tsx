import React from 'react';
import './AppLoading.scss';

// svgs
import { ReactComponent as LogoIcon } from '~/assets/svgs/logo.svg';

export const AppLoading = () => {
    return (
        <div className="ws-app-loading">
            <LogoIcon />
        </div>
    );
};
