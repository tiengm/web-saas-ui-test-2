import React from 'react';
import classnames from 'classnames';
import './Avatar.scss';

// hooks
import { useHover } from '~/hooks';

interface AvatarProps {
    src: string;
    width: number;
    height: number;
    noHover?: boolean;
}

export const Avatar = ({ src, width, height, noHover }: AvatarProps) => {
    const { hovered, eventHandlers } = useHover();
    return (
        <div className="ws-avatar" {...eventHandlers}>
            <div className="ws-avatar-container" style={{ width: `${width}px`, height: `${height}px` }}>
                <div className="ws-avatar-card">
                    <div className="ws-avatar-card-container">
                        <div className="ws-avatar-card__picture" style={{ backgroundImage: `url(${src})` }}></div>
                    </div>
                </div>
            </div>
            {!noHover && (
                <div className={classnames('ws-avatar-overlay', { 'ws-avatar-overlay--hover': hovered })}></div>
            )}
        </div>
    );
};
