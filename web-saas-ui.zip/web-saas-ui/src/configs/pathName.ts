export const PATH_NAME = {
    REGISTER: '/register',
    LOGIN: '/login',
    FORGOT_PASSWORD: '/forgot-password',
    DASHBOARD: '/',
    EDITOR: '/editor',
    NOT_FOUND: '/not-found',
};
